package com.example.flappybot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 42
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        status = TextView(this)
        status.textSize = 17f
        root.addView(status)

        fun button(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { onClick() }
            root.addView(b)
        }

        button("Step 1: Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("Step 1b: Open app info (for 'Allow restricted settings')") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("START BOT") { startBot() }
        button("STOP BOT") { startService(Intent(this, BotService::class.java).setAction("STOP")) }
        button("Save test picture (bot must be running)") {
            BotService.snapshotAt = SystemClock.uptimeMillis() + 6000
            Toast.makeText(this, "Go to your game now. A picture is saved in 6 seconds.", Toast.LENGTH_LONG).show()
        }

        val help = TextView(this)
        help.textSize = 14f
        help.setPadding(0, pad, 0, 0)
        help.text = "How to use:\n" +
            "1. Turn on 'Flappy Bot' in Accessibility settings (Step 1).\n" +
            "2. Press START BOT, choose 'Entire screen' and 'Start now'.\n" +
            "3. Open your game. The bot taps by itself when it sees the game.\n" +
            "4. To stop: pull down the notification shade and press STOP BOT, or come back here.\n" +
            "Test pictures are saved in Pictures/FlappyBot."
        root.addView(help)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val a11y = if (TapService.instance != null) "ON" else "OFF (do Step 1)"
        val bot = if (BotService.running) "RUNNING" else "stopped"
        status.text = "Accessibility service: $a11y\nBot: $bot"
    }

    private fun startBot() {
        if (TapService.instance == null) {
            Toast.makeText(this, "Turn on the accessibility service first (Step 1).", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            Toast.makeText(this, "Allow notifications, then press START BOT again.", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Bot started. Now open your game.", Toast.LENGTH_LONG).show()
        }
    }
}
