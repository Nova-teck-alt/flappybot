package com.example.flappybot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.WindowManager

class BotService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var snapshotAt = 0L   // uptime (ms) when a test picture should be saved; 0 = none
        const val STEP = 2              // look at every 2nd pixel
        const val SHRINK = 3            // capture at 1/3 of real screen size
        const val CHANNEL = "bot"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val controller = Controller()
    private var realW = 0
    private var realH = 0
    private var lastNotify = 0L
    private var stopped = false
    private var finishing = false
    private var grid = IntArray(0)

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra<Intent>("data")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopBot()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        stopped = false
        finishing = false
        createChannel()
        // Must happen BEFORE getMediaProjection on Android 14+
        startForeground(1, buildNotification("Starting..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val t = HandlerThread("bot")
        t.start()
        thread = t
        val handler = Handler(t.looper)

        val mgr = getSystemService(MediaProjectionManager::class.java)
        val proj = mgr.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopBot() }
        }, handler)

        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        realW = bounds.width()
        realH = bounds.height()
        val cw = realW / SHRINK
        val ch = realH / SHRINK
        val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader = r
        display = proj.createVirtualDisplay(
            "flappybot", cw, ch, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage()
            if (img != null) {
                try { process(img) } catch (e: Exception) { /* skip bad frame */ }
                try { img.close() } catch (e: Exception) { }
            }
        }, handler)
        running = true
        return START_NOT_STICKY
    }

    private fun process(img: Image) {
        if (stopped || finishing) return
        val now = SystemClock.uptimeMillis()
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val gw = img.width / STEP
        val gh = img.height / STEP
        if (grid.size != gw * gh) grid = IntArray(gw * gh)
        for (gy in 0 until gh) {
            val rowBase = gy * STEP * rs
            for (gx in 0 until gw) {
                val idx = rowBase + gx * STEP * ps
                val r = buf.get(idx).toInt() and 255
                val g = buf.get(idx + 1).toInt() and 255
                val b = buf.get(idx + 2).toInt() and 255
                grid[gy * gw + gx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val scene = Detector.analyze(grid, gw, gh, controller.lastGap)
        val action = controller.decide(scene, now, gw, gh)
        if (action != Action.NONE) TapService.instance?.tap(realW / 2f, realH / 2f)

        if (snapshotAt in 1..now) {
            snapshotAt = 0
            saveSnapshot(gw, gh, scene)
        }
        if (controller.passed >= Cfg.TARGET) {
            finishing = true
            notifyText("Counted ${controller.passed} passes - target reached, bot stopped.")
            Handler(Looper.getMainLooper()).post { stopBot() }
            return
        }
        if (now - lastNotify > 700) {
            lastNotify = now
            val state = when {
                !scene.gameVisible -> "game not on screen"
                scene.cat == null -> "cat not seen"
                else -> "cat seen"
            }
            notifyText("Passes counted: ${controller.passed} | $state")
        }
    }

    private fun saveSnapshot(gw: Int, gh: Int, scene: Scene) {
        val sc = 3
        val small = Bitmap.createBitmap(grid, gw, gh, Bitmap.Config.ARGB_8888)
        val big = Bitmap.createScaledBitmap(small, gw * sc, gh * sc, false).copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(big)
        val p = Paint()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.GREEN
        scene.cat?.let { c.drawRect((it.x0 * sc).toFloat(), (it.y0 * sc).toFloat(), (it.x1 * sc).toFloat(), (it.y1 * sc).toFloat(), p) }
        p.color = Color.RED
        for (h in scene.heads) c.drawRect((h.x0 * sc).toFloat(), (h.y0 * sc).toFloat(), (h.x1 * sc).toFloat(), (h.y1 * sc).toFloat(), p)
        p.color = Color.MAGENTA
        for (col in scene.columns) {
            c.drawLine((col.x0 * sc).toFloat(), (col.gapTop * sc).toFloat(), (col.x1 * sc).toFloat(), (col.gapTop * sc).toFloat(), p)
            c.drawLine((col.x0 * sc).toFloat(), (col.gapBottom * sc).toFloat(), (col.x1 * sc).toFloat(), (col.gapBottom * sc).toFloat(), p)
        }
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "flappybot_test_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FlappyBot")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        contentResolver.openOutputStream(uri)?.use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }
        notifyText("Test picture saved to Pictures/FlappyBot")
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Bot status", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, BotService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause), "STOP BOT", stopIntent
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Flappy Bot")
            .setContentText(text)
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    private fun notifyText(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    private fun stopBot() {
        if (stopped) return
        stopped = true
        running = false
        try { display?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { thread?.quitSafely() } catch (e: Exception) { }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
