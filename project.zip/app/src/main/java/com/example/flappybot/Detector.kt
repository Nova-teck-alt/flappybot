package com.example.flappybot

class Box(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
    val cx: Int get() = (x0 + x1) / 2
    val cy: Int get() = (y0 + y1) / 2
    val w: Int get() = x1 - x0 + 1
    val h: Int get() = y1 - y0 + 1
}

/** One pair of sunflowers. gapTop/gapBottom are the free space between the flower heads. */
class Column(val x0: Int, val x1: Int, val gapTop: Int, val gapBottom: Int, val complete: Boolean) {
    val cx: Int get() = (x0 + x1) / 2
}

class Scene(val gameVisible: Boolean, val cat: Box?, val heads: List<Box>, val columns: List<Column>)

object Detector {
    private const val SKY: Byte = 1
    private const val PINK: Byte = 2
    private const val FLOWER: Byte = 3

    // Colors measured from the game screenshot:
    // sky (123,192,231), cat pink (248,190,214), petals (252,233,95) and (242,175,62)
    fun classify(r: Int, g: Int, b: Int): Byte {
        if (b > r + 60 && b > 150) return SKY
        if (r > 200 && g > 105 && b < 140 && r - b > 90) return FLOWER
        if (r > 225 && g in 160..215 && b in 180..235 && b > g + 8) return PINK
        return 0
    }

    private class Comp(val box: Box, val area: Int)

    private fun components(cls: ByteArray, w: Int, h: Int, kind: Byte): List<Comp> {
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        val out = ArrayList<Comp>()
        for (start in 0 until w * h) {
            if (cls[start] != kind || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var x0 = w; var y0 = h; var x1 = 0; var y1 = 0; var area = 0
            while (sp > 0) {
                val p = stack[--sp]
                val px = p % w
                val py = p / w
                area++
                if (px < x0) x0 = px
                if (px > x1) x1 = px
                if (py < y0) y0 = py
                if (py > y1) y1 = py
                for (dy in -1..1) {
                    val ny = py + dy
                    if (ny < 0 || ny >= h) continue
                    for (dx in -1..1) {
                        val nx = px + dx
                        if (nx < 0 || nx >= w) continue
                        val q = ny * w + nx
                        if (!seen[q] && cls[q] == kind) {
                            seen[q] = true
                            stack[sp++] = q
                        }
                    }
                }
            }
            out.add(Comp(Box(x0, y0, x1, y1), area))
        }
        return out
    }

    /** grid = packed 0xAARRGGBB pixels, w*h. estGap = last known gap size (0 = unknown). */
    fun analyze(grid: IntArray, w: Int, h: Int, estGap: Int): Scene {
        val cls = ByteArray(w * h)
        var sky = 0
        for (i in 0 until w * h) {
            val c = grid[i]
            val k = classify((c shr 16) and 255, (c shr 8) and 255, c and 255)
            cls[i] = k
            if (k == SKY) sky++
        }
        // If less than a quarter of the screen is sky-blue, the game is not on screen.
        if (sky < w * h * 0.25) return Scene(false, null, emptyList(), emptyList())

        val minCat = (0.0012 * w * h).toInt()
        var cat: Box? = null
        var best = 0
        for (c in components(cls, w, h, PINK)) {
            // ignore pink pigs on the ground (bottom 20%)
            if (c.box.cy < h * 0.80 && c.area >= minCat && c.area > best) {
                best = c.area
                cat = c.box
            }
        }

        val minHead = (0.003 * w * h).toInt()
        val heads = components(cls, w, h, FLOWER)
            .filter { it.area >= minHead && it.box.w >= w * 0.05 }
            .map { it.box }
            .sortedBy { it.cx }

        val gap = if (estGap > 0) estGap else (h * 0.38).toInt()
        val cols = ArrayList<Column>()
        var i = 0
        while (i < heads.size) {
            val grp = arrayListOf(heads[i])
            var j = i + 1
            while (j < heads.size && Math.abs(heads[j].cx - grp[0].cx) < grp[0].w * 0.8) {
                grp.add(heads[j]); j++
            }
            i = j
            val up = grp.minByOrNull { it.cy }!!
            val lo = grp.maxByOrNull { it.cy }!!
            val x0 = grp.minOf { it.x0 }
            val x1 = grp.maxOf { it.x1 }
            if (lo.cy - up.cy > up.h) {
                val mid = (up.cy + lo.cy) / 2
                val gt = grp.filter { it.cy <= mid }.maxOf { it.y1 }
                val gb = grp.filter { it.cy > mid }.minOf { it.y0 }
                cols.add(Column(x0, x1, gt, gb, true))
            } else {
                val uy0 = grp.minOf { it.y0 }
                val uy1 = grp.maxOf { it.y1 }
                if ((uy0 + uy1) / 2 < h * 0.5) cols.add(Column(x0, x1, uy1, uy1 + gap, false))
                else cols.add(Column(x0, x1, uy0 - gap, uy0, false))
            }
        }
        return Scene(true, cat, heads, cols)
    }
}
