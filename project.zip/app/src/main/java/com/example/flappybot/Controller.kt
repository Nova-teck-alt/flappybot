package com.example.flappybot

object Cfg {
    const val TARGET = 50            // stop the bot after this many counted passes
    const val AIM_FRAC = 0.55f       // where in the gap to aim (0 = top, 1 = bottom)
    const val DEFAULT_AIM = 0.45f    // where to hover when no obstacle is visible (fraction of screen height)
    const val COOLDOWN_MS = 110L     // minimum time between taps
    const val RISE_LIMIT = 0.30f     // do not tap if already rising faster than this (screens/second)
    const val RESTART_AFTER_MS = 1200L
    const val RESTART_EVERY_MS = 1500L
}

enum class Action { NONE, TAP, RESTART_TAP }

class Controller {
    var passed = 0
        private set
    var lastGap = 0
        private set

    private var lastTapAt = 0L
    private var lastRestartAt = 0L
    private var noCatSince = -1L
    private var prevCy = -1
    private var prevAt = 0L
    private var vy = 0f
    private var prevColCx = -1
    private var prevColX1 = -1

    fun decide(s: Scene, now: Long, gw: Int, gh: Int): Action {
        if (!s.gameVisible) {
            noCatSince = -1; prevCy = -1; prevColCx = -1
            return Action.NONE
        }
        val cat = s.cat
        if (cat == null) {
            if (noCatSince < 0) noCatSince = now
            prevCy = -1; prevColCx = -1
            if (now - noCatSince > Cfg.RESTART_AFTER_MS && now - lastRestartAt > Cfg.RESTART_EVERY_MS) {
                lastRestartAt = now
                return Action.RESTART_TAP
            }
            return Action.NONE
        }
        if (noCatSince >= 0 && now - noCatSince > Cfg.RESTART_AFTER_MS) {
            passed = 0 // cat is back after a game over: new game
        }
        noCatSince = -1

        // vertical speed estimate (cells per second, positive = falling)
        if (prevCy >= 0 && now > prevAt) {
            val v = (cat.cy - prevCy) * 1000f / (now - prevAt)
            vy = vy * 0.5f + v * 0.5f
        }
        prevCy = cat.cy
        prevAt = now

        for (c in s.columns) if (c.complete) lastGap = c.gapBottom - c.gapTop

        val target = s.columns.firstOrNull { it.x1 >= cat.x0 }

        // count a pass when the column we were chasing has gone behind the cat
        if (prevColCx >= 0) {
            val changed = target == null || target.cx > prevColCx + gw * 0.05
            if (changed && prevColX1 <= cat.x1 + gw * 0.06) passed++
            if (changed) { prevColCx = -1 }
        }
        if (target != null) {
            if (prevColCx < 0 || target.cx <= prevColCx + gw * 0.05) {
                prevColCx = target.cx; prevColX1 = target.x1
            }
        }

        val aim = if (target != null)
            (target.gapTop + (target.gapBottom - target.gapTop) * Cfg.AIM_FRAC).toInt()
        else (gh * Cfg.DEFAULT_AIM).toInt()

        val risingFast = (vy / gh) < -Cfg.RISE_LIMIT
        val tooLow = cat.cy > aim ||
            (target != null && cat.y1 > target.gapBottom - (gh * 0.02).toInt())
        if (tooLow && !risingFast && now - lastTapAt >= Cfg.COOLDOWN_MS) {
            lastTapAt = now
            return Action.TAP
        }
        return Action.NONE
    }
}
